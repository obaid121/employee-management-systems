import { TableRowHoverDirective } from './table-row-hover.directive';

describe('TableRowHoverDirective', () => {
  it('should create an instance', () => {
    const directive = new TableRowHoverDirective();
    expect(directive).toBeTruthy();
  });
});
